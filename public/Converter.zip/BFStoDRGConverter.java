import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * This class converts a medical dataset from the BFS (Bundesamt für Statistik)
 * to the SwissDRG grouper input format. According to the version of the BFS
 * dataset, the positions of the variables have to be adapted. This version is
 * configured for the BFS dataset of 2009 and 2012 (including case conflations).
 *
 * For questions, remarks and corrections, please contact tim.peter@swissdrg.org.
 * 
 * Copyright (C) 2011 SwissDRG AG
 * 
 * This program is free software: you can redistribute it and/or modify it under
 * the terms of the GNU General Public License as published by the Free Software
 * Foundation, version 3 of the License.
 * 
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
 * details.
 * 
 * You should have received a copy of the GNU General Public License along with
 * this program. If not, see <http://www.gnu.org/licenses/>.
 * 
 * @author Tim Peter
 * @copyright SwissDRG 2011
 */
public class BFStoDRGConverter {

	/**
	 * position of the BFS variable 0.3.V01 (MN record present).
	 * 
	 * Please check the position variables. They are equivalent to the
	 * first column ('Rang') in the documentation of the variables of the
	 * medical statistics (BFS), which corresponds to the version applied in the
	 * input file.
	 */
	private static int POS_03V01 = 7;

	/** position of the BFS variable 0.3.V02 (MP record present). */
	private static int POS_03V02 = 8;

	/** position of the BFS variable 0.3.V03 (MD record present). */
	private static int POS_03V03 = 9;

	/** position of the BFS variable 0.3.V04 (MK record present). */
	private static int POS_03V04 = 10;

	/** position of the BFS variable 1.1.V01 (sex). */
	private static int POS_11V01 = 11;

	/** position of the BFS variable 1.1.V02 (birthdate). */
	private static int POS_11V02 = 12;

	/** position of the BFS variable 1.1.V03 (age). */
	private static int POS_11V03 = 13;

	/** position of the BFS variable 1.2.V01 (entry date and hour). */
	private static int POS_12V01 = 16;

	/** position of the BFS variable 1.2.V02 (whereabout before entry). */
	private static int POS_12V02 = 17;

	/** position of the BFS variable 1.2.V03 (entry mode). */
	private static int POS_12V03 = 18;

	/** position of the BFS variable 1.3.V04 (administrative vacation). */
	private static int POS_13V04 = 23;

	/** position of the BFS variable 1.5.V01 (exit date and hour). */
	private static int POS_15V01 = 26;

	/** position of the BFS variable 1.5.V02 (decision for exit). */
	private static int POS_15V02 = 27;

	/** position of the BFS variable 1.5.V03 (whereabout after exit). */
	private static int POS_15V03 = 28;

	/** position of the BFS variable 1.6.V01 (principal diagnosis). */
	private static int POS_16V01 = 30;

	/** position of the BFS variable 1.6.V03 (first secondary diagnosis). */
	private static int POS_16V03 = 32;

	/** position of the BFS variable 1.7.V01 (main procedure). */
	private static int POS_17V01 = 40;

	/** position of the BFS variable 1.7.V03 (first secondary diagnosis). */
	private static int POS_17V03 = 42;

	/** position of the BFS variable 2.2.V04 (weight). */
	private static int POS_22V04 = 7;

	/** position of the BFS variable 4.5.V01 (weight). */
	private static int POS_45V01 = 661;

	/** position of the BFS variable 4.4.V01 (ventilation time in hours). */
	private static int POS_44V01 = 655;

	/** position of the BFS variable 4.2.V010 (main diagnosis). */
	private static int POS_42V010 = 4;

	/** position of the BFS variable 4.2.V010 (MD addition to the main diagnosis, is treated as a secondary diagnosis). */
	private static int POS_42V020 = 7;

	/** position of the BFS variable 4.2.V030 (first secondary diagnosis). */
	private static int POS_42V030 = 8;

	/**
	 * step size between diagnoses in 4.2. Amount of variables for one
	 * diagnosis.
	 */
	private static int DIAGS_STEPSIZE = 3;

	/** position of the BFS variable 4.3.V010 (main procedure). */
	private static int POS_43V010 = 155;

	/** position of the BFS variable 4.6.V01 (Fallnummer). */
	private static int POS_46V01 = 663;


	/** position of the BFS variable 4.3.V030 (first secondary procedure). */
	private static int POS_43V020 = 160;

	/**
	 * step size between diagnoses in 4.3. Amount of variables for one
	 * procedure.
	 */
	private static int PROCS_STEPSIZE = 5;

	/** position of the BFS variable 4.7.V01 (first intermediate exit). */
	private static int POS_47V01 = 664;

	/** maximum number of possible interruptions. */
	private static int MAX_INTERRUPT = 4;

	/** file name of the bfs input file. */
	private String bfsFile;
	/** file name of the swissdrg grouper file. */
	private String drgFile;
	/** the records of the currently processed case. */
	private String[] currentMBLine;
	private String[] currentMNLine;
	private String[] currentMPLine;
	private String[] currentMDLine;
	private String[] currentMKLine;


	/** statistics. */
	private int numValidCases = 0;
	private int numInvalidCases = 0;

	private long millisPerDay;

	/**
	 * Convert a BFS File to a SwissDRG Grouper input file
	 * 
	 * @param argument
	 *            one is a BFS-formatted input file, argument two is the SwissDRG
	 *            formatted output file
	 */
	public static void main(String[] args) {
		if (args.length != 2) {
			System.out.println("Usage: java BFStoDRGConverter bfs-input.txt swissdrg-grouper.txt");
			System.exit(0);
		}

		BFStoDRGConverter converter = new BFStoDRGConverter(args[0], args[1]);
		converter.convert();
	}

	/** Constructor. */
	public BFStoDRGConverter(String bfsFile, String drgFile) {
		this.bfsFile = bfsFile;
		this.drgFile = drgFile;
		this.millisPerDay = 24 * 3600 * 1000;
	}

	/**
	 * Convert the file, case by case. Incomplete cases produce a warning and
	 * are not converted, but the convertion is not cancelled. A wrong order of
	 * the records (MX, MB, MN ...) leads to an error. Convertion will be
	 * cancelled.
	 */
	public void convert() {
		String line = "";
		try {
			DataInputStream inStream = new DataInputStream(new FileInputStream(
					this.bfsFile));
			BufferedReader in = new BufferedReader(new InputStreamReader(
					inStream));

			FileWriter outStream = new FileWriter(this.drgFile);
			BufferedWriter out = new BufferedWriter(outStream);

			String lineDelimiter = System.getProperty("line.separator");

			line = in.readLine();
			if (!"MX".equals(line.substring(0, 2))) {
				System.out
						.println("Fehler: Ungültiges BFS Datenformat: Kein MX record am Anfang");
				System.exit(1);
			}

			while ((line = in.readLine()) != null) {
				this.currentMNLine = null;
				this.currentMPLine = null;
				this.currentMDLine = null;
				this.currentMKLine = null;
				this.currentMBLine = (line + "l").split("\\|");// + "l" workaround to load the whole record to the end, even if there are empty variables at the end
				
				try {

					if (!"MB".equals(this.currentMBLine[0]))
						this.errorUnexpectedRecord("MB", line);

					if ("1".equals(this.currentMBLine[POS_03V01 - 1])) {
						this.currentMNLine = (in.readLine()+"l").split("\\|");
						if (!"MN".equals(this.currentMNLine[0]))
							this.errorUnexpectedRecord("MN", line);
					}

					if ("1".equals(this.currentMBLine[POS_03V02 - 1])) {
						this.currentMPLine = (in.readLine()+"l").split("\\|");
						if (!"MP".equals(this.currentMPLine[0]))
							this.errorUnexpectedRecord("MP", line);
					}

					if ("1".equals(this.currentMBLine[POS_03V03 - 1])) {
						this.currentMDLine = (in.readLine()+"l").split("\\|");
						if (!"MD".equals(this.currentMDLine[0]))
							this.errorUnexpectedRecord("MD", line);
					}

					if ("1".equals(this.currentMBLine[POS_03V04 - 1])) {
						this.currentMKLine = (in.readLine()+"l").split("\\|");
						if (!"MK".equals(this.currentMKLine[0]))
							this.errorUnexpectedRecord("MK", line);
					}
					out.write(this.convertCase() + lineDelimiter);
					this.numValidCases++;
				} catch (Exception e) {
					this.numInvalidCases++;
					System.out
							.println("Warnung: Zeile: "
									+ line
									+ " konnte nicht konvertiert werden. Der Eintrag ist nicht komplett");
					e.printStackTrace();
				}
			}
			// Close the streams
			inStream.close();
			out.close();
		} catch (IOException e) {
			System.err.println("Error reading/writing files");
			e.printStackTrace();
		}

		this.printStatistics();
	}

	private void errorUnexpectedRecord(String record, String line) {
		System.out.println("Fehler: Ungültiges BFS Datenformat: " + record
				+ " record wurde bei folgender Zeile erwartet: " + line);
		System.exit(1);
	}

	private void printStatistics() {
		System.out.println("Konvertierung fertig:");
		System.out.println("Konvertierte Fälle: "
				+ (this.numInvalidCases + this.numValidCases));
		System.out.println("Gültige Fälle (konvertiert): " + this.numValidCases);
		System.out.println("Ungültige Fälle (nicht konvertiert): "
				+ this.numInvalidCases);
	}

	/**
	 * Convert the current case.
	 * 
	 * @return one grouper input formatted case
	 */
	private String convertCase() {
		// get exit date, entry date, birthdate and administrative vacation days
		long entryDate = this.getDate(this.currentMBLine[POS_12V01 - 1]);
		long exitDate = this.getDate(this.currentMBLine[POS_15V01 - 1]);
		long birthDate = this.getDate(this.currentMBLine[POS_11V02 - 1]);
		int vacationDays = (int) Math.floor(Double
				.valueOf(this.currentMBLine[POS_13V04 - 1]) / 24.00);

		// primary key
		StringBuffer drg = new StringBuffer(this.createPrimaryKey());
		drg.append(";");
		// age years
		drg.append(this.currentMBLine[POS_11V03 - 1] + ";");
		// age days
		if (Integer.valueOf(this.currentMBLine[POS_11V03 - 1]) < 1) {
			if (entryDate == birthDate)
				drg.append("1");
			else {
				drg.append(String.valueOf(entryDate - birthDate));
			}
			// weight
			drg.append(";");
			if (this.currentMNLine != null)
				drg.append(this.currentMNLine[POS_22V04 - 1]);
			else if (this.currentMDLine != null)
				drg.append(this.currentMDLine[POS_45V01 - 1]);
			else
				drg.append("0");
			drg.append(";");
		} else
			drg.append(";;");

		// sex
		if ("1".equals(this.currentMBLine[POS_11V01 - 1]))
			drg.append("M;");
		else if ("2".equals(this.currentMBLine[POS_11V01 - 1]))
			drg.append("W;");
		else
			drg.append("U;");

		// entry status
		if ("3".equals(this.currentMBLine[POS_12V03 -1]))
			drg.append("01;");	
		else if ("6".equals(this.currentMBLine[POS_12V02 - 1]) && !"5".equals(this.currentMBLine[POS_12V03 -1]))
			drg.append("11;");
		else if ("6".equals(this.currentMBLine[POS_12V02 - 1]) && "5".equals(this.currentMBLine[POS_12V03 -1]))
			drg.append("06;");
		else
			drg.append("01;");

		// exit status
		String v15v02 = this.currentMBLine[POS_15V02 - 1];
		String v15v03 = this.currentMBLine[POS_15V03 - 1];
		if ("5".equals(v15v02))
			drg.append("07;");
		else if ("6".equals(v15v03))
			drg.append("06;");
		else if ("2".equals(v15v02) || "3".equals(v15v02))
			drg.append("04;");
		else
			drg.append("00;");

		// length of stay (including case conflations)
		long los = 0;
		long currentEntryDate = entryDate;
		long currentExitDate = exitDate;
		for (int nInterrupt = 0; nInterrupt < MAX_INTERRUPT; nInterrupt++) {
			boolean finish = false;
			if (this.currentMDLine == null
					|| this.currentMDLine.length < POS_47V01 + 3 * nInterrupt
					|| "".equals(this.currentMDLine[POS_47V01 - 1 + 3
							* nInterrupt])) { // finish
				currentExitDate = exitDate;
				finish = true;
			} else {
				currentExitDate = this.getDate(this.currentMDLine[POS_47V01 - 1
						+ 3 * nInterrupt]);
			}
			if (currentEntryDate == currentExitDate)
				los += 1;
			else
				los += currentExitDate - currentEntryDate;
			if (finish)
				break;
			currentEntryDate = this.getDate(this.currentMDLine[POS_47V01 + 3
					* nInterrupt]);
		}
		
		drg.append((los - vacationDays) + ";");

		// same day flag
		drg.append("0;");

		// ventilation time
		if (this.currentMDLine != null)
			drg.append(this.currentMDLine[POS_44V01 - 1]);

		drg.append(";");

		// diagnoses and procedures
		if (this.currentMDLine != null)
			drg.append(this.getProcDiagsFromMD());
		else
			drg.append(this.getProcDiagsFromMB());

		return drg.toString();
	}

	/**
	 * Get the diagnoses and the procedures from the minimal dataset MB.
	 * 
	 * @return
	 */
	private String getProcDiagsFromMB() {
		StringBuffer diags = new StringBuffer(this.currentMBLine[POS_16V01 - 1] + ";");
		for (int i = 0; i < 8; i++)
			diags.append(this.currentMBLine[POS_16V03 - 1 + i] + ";");
		for (int i = 0; i < 91; i++)
			diags.append(";");
		StringBuffer procs = new StringBuffer(this.currentMBLine[POS_17V01 - 1] + ";");
		for (int i = 0; i < 8; i++)
			procs.append(this.currentMBLine[POS_17V03 - 1 + i] + ";");
		for (int i = 0; i < 91; i++)
			procs.append(";");
		return diags.toString() + procs.toString();
	}

	/**
	 * Get the diagnoses and the procedures from the additional patient group
	 * dataset MD.
	 * 
	 * @return
	 */
	private String getProcDiagsFromMD() {
		StringBuffer diags = new StringBuffer(
				this.currentMDLine[POS_42V010 - 1] + ";");

		String mdAddition = this.currentMDLine[POS_42V020 - 1];

		mdAddition = mdAddition.replace("*","");
		mdAddition = mdAddition.replace("!","");
		mdAddition = mdAddition.replace("†","");

		diags.append(mdAddition + ";");

		for (int i = 0; i < 49; i++)
			diags.append(this.currentMDLine[POS_42V030 - 1 + i * DIAGS_STEPSIZE] + ";");
		for (int i = 0; i < 49; i++)
			diags.append(";");
		StringBuffer procs = new StringBuffer("");
		this.appendProcedure(procs, POS_43V010 - 1);
		for (int i = 0; i < 99; i++)
			this.appendProcedure(procs, POS_43V020 - 1 + i * PROCS_STEPSIZE);
		
		return diags.toString() + procs.toString();
	}

	private void appendProcedure(StringBuffer procs, int index) {
		procs.append(this.currentMDLine[index]);
		String side = this.currentMDLine[index + 1];
		if("0".equals(side)) side = "B";
		if("1".equals(side)) side = "R";
		if("2".equals(side)) side = "L";
		if("3".equals(side) || "9".equals(side)) side = "";
		procs.append(":" + side);
		String date = this.currentMDLine[index + 2];
		if(date.length() >= 8)
			procs.append(":" + date.substring(0, 8));
		
		procs.append(";");
	}

	/**
	 * Get the elapsed amount of days since 01.01.1970.
	 * 
	 * @param string date
	 * @return elapsed days
	 */
	private long getDate(String dateString) {
		Calendar cal = new GregorianCalendar();
		int year = Integer.valueOf(dateString.substring(0, 4));
		int month = Integer.valueOf(dateString.substring(4, 6));
		int day = Integer.valueOf(dateString.substring(6, 8));
		cal.set(year, month - 1, day, 0, 0, 0);
		return Math.round((double)cal.getTimeInMillis() / this.millisPerDay);		
	}

	/**
	 * Overwrite this method to suit your needs.
	 * Currently it's the variable 4.6.V01 
	 *
	 * @return primary key
	 */
	private String createPrimaryKey() {
		return this.currentMDLine[POS_46V01 - 1];
	}

}

